using System.ComponentModel.DataAnnotations;

namespace IGB.Smartphones.Api.Dtos;

public class CadastrarClienteRequest
{
    [Required(ErrorMessage = "O nome é obrigatório.")]
    [MaxLength(150)]
    public string Nome { get; set; } = string.Empty;

    [Required(ErrorMessage = "O gênero é obrigatório.")]
    [MaxLength(30)]
    public string Genero { get; set; } = string.Empty;

    [Required(ErrorMessage = "A data de nascimento é obrigatória.")]
    public DateOnly DataNascimento { get; set; }

    [Required(ErrorMessage = "O CPF é obrigatório.")]
    [RegularExpression(@"^\d{11}$", ErrorMessage = "O CPF deve conter 11 dígitos.")]
    public string CPF { get; set; } = string.Empty;

    [Required(ErrorMessage = "O tipo de telefone é obrigatório.")]
    [MaxLength(20)]
    public string TelefoneTipo { get; set; } = string.Empty;

    [Required(ErrorMessage = "O DDD é obrigatório.")]
    [RegularExpression(@"^\d{2}$", ErrorMessage = "O DDD deve conter 2 dígitos.")]
    public string DDD { get; set; } = string.Empty;

    [Required(ErrorMessage = "O número de telefone é obrigatório.")]
    [RegularExpression(@"^\d{8,9}$", ErrorMessage = "O número de telefone deve conter 8 ou 9 dígitos.")]
    public string TelefoneNumero { get; set; } = string.Empty;

    [Required(ErrorMessage = "O e-mail é obrigatório.")]
    [EmailAddress(ErrorMessage = "Informe um e-mail válido.")]
    [MaxLength(150)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "A senha é obrigatória.")]
    public string Senha { get; set; } = string.Empty;

    [Required(ErrorMessage = "A confirmação de senha é obrigatória.")]
    public string ConfirmacaoSenha { get; set; } = string.Empty;

    [Required(ErrorMessage = "O endereço de cobrança é obrigatório.")]
    public EnderecoRequest EnderecoCobranca { get; set; } = new();

    [Required(ErrorMessage = "O endereço de entrega é obrigatório.")]
    public EnderecoEntregaRequest EnderecoEntrega { get; set; } = new();
}
